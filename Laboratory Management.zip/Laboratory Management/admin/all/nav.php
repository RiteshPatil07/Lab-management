<!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top g2login" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header ">
              
                </button>
                <span class="navbar-brand g2textsh" style="color:WHITE;padding-left:400px;" ><i class="fa  fa-flask fa-fw"></i>ONLINE HEALTHCARE SYSTEM</span>
            </div>
            <!-- /.navbar-header -->

          
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar g2login" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        
                        <li>
                            <a href="index"  ><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                        </li>
						<li>
                            <a href="lab_req"  ><i class="fa fa-info-circle fa-fw"></i>LAB REQUEST</a>
                        </li>
                         <li>
                            <a href="change_pass"><i class="fa fa-gear fa-fw"></i>Change Password</a>
                        </li>
                     <li><a href="../logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>