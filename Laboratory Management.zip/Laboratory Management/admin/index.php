<?php
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["adminuser"]))
{
session_unset(); 
session_destroy();
header("location:../login");	
}
else
{
$user=$_SESSION["adminuser"];
}


$conn=$g2->db();

$sql="SELECT * FROM `lab_reg` ";
$res=$conn->query($sql);
 $labreg=$res->num_rows;


$sql="SELECT * FROM `lab_approve` ";
$res=$conn->query($sql);
 $app=$res->num_rows;	

$noapp=$labreg-$app;



?>


<!DOCTYPE html>
<html lang="en">

<head>

    <?php include"all/headcontent.php"; ?>

</head>

<body class="g2login">
 <div id="wrapper" >

        <?php include"all/nav.php"; ?>
        <!-- Page Content -->
        <div id="page-wrapper" class="">
            <div class="container-fluid ">
                <div class="row " >
                    <div class="col-lg-12 ">
                        
					
		            <br/>
						 <div class="col-lg-3 ">
					<div class="panel g2login g2boxsh g2textsh">
                        <div class="panel-heading" >
                            <div class="row">
                                <div class="col-xs-3">
                                   <div >LAB REGISTERED
                                </div>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $labreg; ?></div>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    </div>
					 <div class="col-lg-3 ">
					<div class="panel g2login g2boxsh g2textsh">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                     <div>APPROVED</div>  </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $app; ?></div>
                                   
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    </div>

                <div class="col-lg-3 ">
					<div class="panel g2login g2boxsh g2textsh">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                   <div>NON APPROVED</div></div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge"><?php echo $noapp; ?></div>
                                    
                                </div>
                            </div>
                        </div>
                       
                    </div>
					
					
						  
                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
<?php include"all/scripts.php"; ?>

</body>

</html>
