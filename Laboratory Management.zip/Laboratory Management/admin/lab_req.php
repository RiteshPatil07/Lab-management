<?php
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["adminuser"]))
{
session_unset(); 
session_destroy();
header("location:../login");	
}
else
{
$user=$_SESSION["adminuser"];
}


$conn=$g2->db();

if(isset($_GET['cancel']))
{
	$cancel=$_GET['cancel'];
	
	if(!empty($cancel))
	{
	$sql="DELETE FROM `lab_approve` WHERE `username`='$cancel'";
    $conn->query($sql);
	
		header("LOCATION:?check=$cancel");
	}
	
	
}
if(isset($_GET['approve']))
{
	$approve=$_GET['approve'];
	
	if(!empty($approve))
	{
	$sql="INSERT INTO `lab_approve`(`username`, `date`) VALUES ('$approve',(now()))";
	
    $conn->query($sql);
	
		header("LOCATION:?check=$approve");
	}
	
	
}



?>


<!DOCTYPE html>
<html lang="en">

<head>

    <?php include"all/headcontent.php"; ?>

</head>

<body class="g2login">
 <div id="wrapper" >

        <?php include"all/nav.php"; ?>
        <!-- Page Content -->
        <div id="page-wrapper" class="">
            <div class="container-fluid ">
                <div class="row " >
                    <div class="col-lg-12 ">
                        
						<div class="col-lg-6 g2login g2boxsh" style="padding:20px;">
										
									
										<div class="g2btnback g2boxsh">
                          <i class="fa  fa-plus fa-fw"> </i> LAB REQUEST
                        </div>
						<div class="col-lg-1  g2boxsh g2btnback" style="padding:5px;" >SR</div>
						<div class="col-lg-4  g2boxsh g2btnback" style="padding:5px;" >NAME</div>	
						 <div class="col-lg-2  g2boxsh g2btnback" style="padding:5px;" >CITY</div>
						 <div class="col-lg-1  g2boxsh g2btnback" style="padding:5px;" >I</div>
						 <div class="col-lg-1  g2boxsh g2btnback" style="padding:5px;" >D</div>
						 <div class="col-lg-1  g2boxsh g2btnback" style="padding:5px;" >A</div>
						<div class="col-lg-2  g2boxsh g2btnback" style="padding:5px;" >CHECK</div>
						<BR/>
										<?php
										$conn=$g2->db();
										$sql="SELECT * FROM `lab_reg`";
										$res=$conn->query($sql);
										$i=1;
										while($r=$res->fetch_array())
										{
											$username=$r['email'];
											$sql1="SELECT * FROM `lab_add` WHERE `username`='$username'";
                                     $res1=$conn->query($sql1);
                               $labinfo=$res1->num_rows;

                               $sql2="SELECT * FROM `lab_doc` WHERE `username`='$username'";
                                $res2=$conn->query($sql2);
                               $labdoc=$res2->num_rows;
							   
							    $sql2="SELECT * FROM `lab_approve` WHERE `username`='$username'";
                                $res2=$conn->query($sql2);
                               $approve=$res2->num_rows;
								
									?><div class="col-lg-1  g2boxsh" style="padding:5px;"><?PHP echo $i; ?></div><?php
											?><div class="col-lg-4  g2boxsh" style="padding:5px;" ><?PHP echo $r['name']; ?></div><?php
											?><div class="col-lg-2  g2boxsh" style="padding:5px;" ><?PHP echo $r['city']; ?></div><?php
											?><div class="col-lg-1  g2boxsh" style="padding:5px;" >
											<i style="font-size:18px;color:<?php if($labinfo!=0){echo 'green';}else{echo 'red';}?>"class="fa  <?php if($labinfo!=0){echo ' fa-check-circle-o';}else{echo 'fa-times-circle-o';}?> fa-fw  " > </i>
											</div><?php
											
											?><div class="col-lg-1  g2boxsh" style="padding:5px;" >
											<i style="font-size:18px;color:<?php if($labdoc!=0){echo 'green';}else{echo 'red';}?>"class="fa  <?php if($labdoc!=0){echo ' fa-check-circle-o';}else{echo 'fa-times-circle-o';}?> fa-fw  " > </i>
											</div><?php
											?><div class="col-lg-1  g2boxsh" style="padding:5px;" >
											<i style="font-size:18px;color:<?php if($approve!=0){echo 'green';}else{echo 'red';}?>"class="fa  <?php if($approve!=0){echo ' fa-check-circle-o';}else{echo 'fa-times-circle-o';}?> fa-fw  " > </i>
											</div><?php
											
											
											?><div class="col-lg-2 g2boxsh g2login" style="padding:5px;"><a href="?check=<?php echo $username?>"  style="color:white;" title="view">CHECK</a></div><?php
									
												$i++;
										}
										?>
										
										
										
										
										
										
										
										</div>
										<div class="col-lg-1" ></div>
										<?php if(isset($_GET['check']))
										{
											$check=$_GET['check'];
											
											 $sql2="SELECT * FROM `lab_approve` WHERE `username`='$check'";
                                $res2=$conn->query($sql2);
                               $approve=$res2->num_rows;
							   
											?>
											<div class="col-lg-5 g2login g2boxsh" style="padding:20px;">
										<?php if($approve==0)
										{ ?>
									<a href="?approve=<?php echo $check; ?>" style="color:white;"><button   class="btn   g2boxsh btn-success" name="" style="border:1px solid white;">APPROVE</button></a>
										<?php } else {?>
										
										<a href="?cancel=<?php echo $check; ?>" style="color:white;"><button   class="btn   g2boxsh btn-danger" name="" style="border:1px solid white;">CANCEL</button></a>
									
										
										<?php } ?>
									<br/><br/>
										<div class="g2btnback g2boxsh">
                          
                        </div>
										<?php
										
										
										$sql="SELECT * FROM `lab_reg` WHERE `email`='$check'";
										$res=$conn->query($sql);
										$r=$res->fetch_array();
										
										$sql1="SELECT * FROM `lab_add` WHERE `username`='$check'";
										$res1=$conn->query($sql1);
										$rr=$res1->fetch_array();
										
										
										?>
										
										<span class="g2btnback ">LAB NAME:</span > <span class=""><?php echo $r['name'];?></span><br/> 
										<span class="g2btnback">EMAIL:</span > <span><?php echo $r['email'];?></span><br/>
										<span class="g2btnback">MOBILE:</span > <span><?php echo $r['mobile'];?></span><br/>
										<span class="g2btnback">PHONE:</span > <span><?php echo $rr['phone'];?></span><br/>
										<span class="g2btnback">STATE:</span > <span><?php echo $rr['state'];?></span><br/>
										<span class="g2btnback">CITY:</span > <span><?php echo $rr['city'];?></span><br/>
										<span class="g2btnback">FULL ADDESS:</span > <span><p><?php echo $rr['full_add'];?> </p></span><br/>
										
										
									<div class="g2btnback g2boxsh">
                          <i class="fa  fa-plus fa-fw"> </i> DOCUMENTS
                        </div>
										<?php
										$conn=$g2->db();
										$sql="SELECT * FROM `lab_doc` WHERE `username`='$check'";
										$res=$conn->query($sql);
										$i=1;
										while($r=$res->fetch_array())
										{ ?><div class="col-lg-2  g2boxsh" style="padding:5px;"><?PHP echo $i; ?></div><?php
											?><div class="col-lg-8  g2boxsh" style="padding:5px;" ><?PHP echo $r['doc_name']; ?></div><?php
											?><div class="col-lg-1 g2boxsh g2login" style="padding:5px;"><a href="../lab/labdoc/<?php echo $r['doc'];?>" target="_BLANCK" title="view"><i class="fa  <?php if($r['type']=='img'){echo 'fa-image';}else{echo 'fa-file-pdf-o';}?> fa-fw g2login " > </i></a></div><?php
									
											$i++;
										}
										?>
											</div>
										
										<?php } ?>
										
		             
						  
                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
<?php include"all/scripts.php"; ?>

</body>

</html>
