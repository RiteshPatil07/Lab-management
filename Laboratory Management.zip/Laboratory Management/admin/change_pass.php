<?php
error_reporting(0);
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["adminuser"]))
{
session_unset(); 
session_destroy();
header("location:../login");    
}
else
{
$user=$_SESSION["adminuser"];
}
$conn=$g2->db();



if(isset($_POST['submit']))
{

    if($g2->change_pass($_POST['opass'],$_POST['npass'],$user)==TRUE)
    {
        $suc=$g2->encrypt("PASSWORD CHANGED SUCCESSFULLY");
        header("LOCATION:?suc=$suc");
    }
    else
    {

        $err=$g2->encrypt("OLD PASSWORD DOSE NOT MATCH");
        header("LOCATION:?err=$err"); 
    }

}


?>


<!DOCTYPE html>
<html lang="en">

<head>

<?php include"all/headcontent.php"; ?>

</head>

<body class="g2login">

 <div id="wrapper" >

        <?php include"all/nav.php"; ?>

        <!-- Page Content -->
        <div id="page-wrapper" class="" style="color:gray;">
            <div class="container-fluid ">
			 <div class="row">
                    <div class="col-lg-6">
		                  <br/>    <?php  if(!empty($_GET['suc'])){$g2->msgsuc($_GET['suc']);} ?> 
                           <?php  if(!empty($_GET['err'])){$g2->msgerr($_GET['err']);} ?> 
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row " >
                    <div class="col-lg-12 ">
					<div class="col-lg-6 g2login g2boxsh" style="padding:20px;">
					<div class="panel panel-default">
					<div class="g2btnback g2boxsh">
                          <i class="fa  fa-plus fa-fw"> </i> CHANGE PASSWORD
                        </div>
						
						<div class="col-lg-12 "><br/>
                       <form action="change_pass" role="form" method="post" >
                                       
                                 <div class="form-group ">
											 <label>OLD PASSWORD:</label>
                                            <input type="password" name="opass" class="form-control g2boxsh"  value="" placeholder="" REQUIRED>
                                      
                                        </div>
                                        <div class="form-group ">
											 <label>NEW PASSWORD:</label>
                                            <input type="password" name="npass" class="form-control g2boxsh"  value="" placeholder="" REQUIRED>
                                        </div>
										
							 <button  type="submit" class="btn  g2btnback g2boxsh" name="submit" style="border:1px solid white;">Submit</button>
                                        
									</form>
					                    </div></div></div><div class="col-lg-1 "></div>
						
										
										
										
										
										
										</div>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
   <?php include"all/scripts.php"; ?>

</body>

</html>
