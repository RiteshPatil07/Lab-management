<?php
error_reporting(0);
session_start();
$_SESSION['user']=$_GET['username'];


?>
<html>
<head>
	<title></title>
	<style type="text/css">
h1{
	margin-top: 40%;
}
	</style>
</head>
<body>
<center><h1>WELCOME TO PATHOLOGY SYSTEM </h1></center>
</body>
</html>