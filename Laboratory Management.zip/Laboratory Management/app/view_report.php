<?php
error_reporting(0);
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["user"]))
{
session_unset(); 
session_destroy();
header("location:./");	
}
else
{
$user=$_SESSION["user"];
}



?>


<!DOCTYPE html>
<html lang="en">

<head>

    
 
 <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

     <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
 <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
  <!-- Custom CSS -->
    <link href="../dist/css/g2.css" rel="stylesheet">
</head>

<body class="">
 <div id="wrapper" >

        
        <!-- Page Content -->
        <div id="page-wrapper" class="">
            <div class="container-fluid ">
                <div class="row " >
                    <div class="col-lg-14 ">
                      

                       
 <div class="panel panel-default col-lg-14 " style="border:none" >
                        <!-- /.panel-heading -->

                        <div class="panel-body" style="color:gray;">
                       <center class="g2boxsh g2login">MY REPORT</center><BR>
                       <?php  $myorder=$g2->myorders_by_id($_GET['order_id']);
                       ?>

                        <BR> PATIANT NAME: <?= $myorder[0]['pname']?>
                       <BR> PATIANT AGE: <?= $myorder[0]['page']?>
                       <BR> PATIANT GENDER: <?= $myorder[0]['gender']?>
                            <div class="dataTable_wrapper">
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>MAIN GROUP</th>
                                            <th>TEST</th>
                                        <th>REPORT</th>
                                        <th>#</th>
                                        <th>OTHER INFO</th>
                                        
                                    
                                        
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                      $myreports=$g2->myreports($_GET['order_id']);
                                        foreach($myreports as $mr)
                                        {

                                        ?>
                                        <tr class="odd gradeX">
                                           
                                           <td><?= $g2->main_group_name($g2->get_main_id($mr['sub_test_id']))?></td>
                                        <td><?= $g2->sub_group_name($mr['sub_test_id']) ?></td>
                                        <td><?= $mr['report'] ?> <?= $g2->find_unit($myorder[0]['labid'],$mr['sub_test_id']); ?></td>
                                        <td><?= $g2->find_lo($myorder[0]['labid'],$mr['sub_test_id'],$myorder[0]['gender']); ?><?= $g2->find_unit($myorder[0]['labid'],$mr['sub_test_id']); ?>-
                                         <?= $g2->find_up($myorder[0]['labid'],$mr['sub_test_id'],$myorder[0]['gender']); ?><?= $g2->find_unit($myorder[0]['labid'],$mr['sub_test_id']); ?>
                                        </td>
                                        <td><?= $mr['other_info'] ?></td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
  <!-- /#wrapper -->    

 
    
						  
                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

  <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>



                    

</body>

</html>
