<?php
error_reporting(0);
include"../g2php/g2main.php";

if(!empty($_REQUEST['name']) && !empty($_REQUEST['email']) && !empty($_REQUEST['mob']) && !empty($_REQUEST['pass']))
{
	
  $conn=$g2->db();

 $name=$_REQUEST['name'];
$email=$_REQUEST['email'];
 $mob=$_REQUEST['mob'];
 $pass=$_REQUEST['pass'];
$type="user";

 $pattern = "/^[0-9]{10}$/";
if(preg_match($pattern, $mob)==1)
{
    
    
    $sql="SELECT * FROM `login` WHERE `username`='$email'";
    $res=$conn->query($sql);
    $rno=$res->num_rows;
    if($rno<1)
    {

$password=$g2->encrypt($pass);

$sql="INSERT INTO `user`(`name`, `email`, `mob`, `date`) VALUES ('$name','$email','$mob',(now()))";
    $conn->query($sql);
    $sql="INSERT INTO `login`(`username`, `pass`, `type`) VALUES ('$email','$password','$type')";
    $conn->query($sql);

      $response["success"] = true;  
       
         $response["email"] = $_REQUEST['email'];
       $response["name"] = $_REQUEST['name'];
		
	}
    else
    {
        $response["success"] = false;  
        $response["err"] = "email id allready registerd";
      
    }
    }
else
{
    $response["success"] = false;  
        $response["err"] = "mobile number is not valid";
   
}
	
}else{
	$response["success"] = false;  
        $response["err"] = "ALL VALUES ARE MANDATORY";
}

    echo json_encode($response);

?>