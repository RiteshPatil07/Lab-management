<?php
error_reporting(0);
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["user"]))
{
session_unset(); 
session_destroy();
header("location:./");	
}
else
{
$user=$_SESSION["user"];
}

if(isset($_GET['addcart']))
{
    $mt=$_GET['mt'];
    if(!isset($_COOKIE['testcart']))
    {
       $test=array($_GET['addcart']);
       setcookie("testcart",serialize($test),time()+(84600*30),"/");
    header("location:?mt=$mt&suc");
    }
    else
    {
        $e=0;
        $test=unserialize($_COOKIE['testcart']);
        foreach($test as $t)
        {
            if($t==$_GET['addcart'])
            {
                $e=1;
            }
        }


         if($e!=1)
         {

        array_push($test, $_GET['addcart']);
 
       setcookie("testcart",serialize($test),time()+(84600*30),"/");
      header("location:?mt=$mt&suc");
    
        }else
        {
             header("location:?mt=$mt&err");
        }
    }


}


?>


<!DOCTYPE html>
<html lang="en">

<head>

 <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

 <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">

     <!-- Custom CSS -->
    <link href="../dist/css/g2.css" rel="stylesheet">
</head>

<body class="">
 <div id="wrapper" >

       
        <!-- Page Content -->
        <div id="page-wrapper" class="">
            <div class="container-fluid ">
                <div class="row " >
                    <div class="col-lg-14 ">
                        <center class="g2boxsh g2login" style="padding:15px;">
                           <?php if(!isset($_GET['mt']))
                        {?>
                          FIND YOUR TEST
                         <?php } 
                       else {
                         ?>
                        <a href="?" style="color:orange;">TEST</a> / <?= $g2->main_group_name($_GET['mt']); ?>
                        <?php } ?>
                        </center><BR>
  
                                  <?php if(isset($_GET['suc'])){?>
                             <div style="text-align:center;"  id="msg" class="alert alert-success alert-dismissable">
                   TEST ADDED INTO TEST CART!
                   </div>
                        <?php }
                          ?>

                              <?php if(isset($_GET['err'])){?>
                             <div style="text-align:center;"  id="msg" class="alert alert-danger alert-dismissable">
                   TEST ALREADY PRESENT INTO TEST CART!
                   </div>
                        <?php }
                          ?>
                        <br>

                        <?php if(!isset($_GET['mt']))
                        {?>
                        
 <div class="panel panel-default col-lg-14"  style="border:none">
                        <!-- /.panel-heading -->
                        <div class="panel-body" style="color:gray;">
                        
                            <div class="dataTable_wrapper">
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                        <th> TEST MAIN GROUP </th>
                                        <th>#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $main_test=$g2->main_test();
                                        foreach($main_test as $mt)
                                        {

                                        ?>
                                        <tr class="odd gradeX">
                                        <td><a href="?mt=<?= $mt['id'] ?>"><?= $mt['name']?></a></td>
                                        <td><a href="?mt=<?= $mt['id']?>">SELECT</a></td>
                                        </td></tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
  <!-- /#wrapper -->    

<?php } 
else {
?>
 <div class="panel panel-default col-lg-14 "  style="border:none">
                        <!-- /.panel-heading -->
                        <div class="panel-body" style="color:gray;">
                           <div class="dataTable_wrapper">
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                        <th> TEST SUB GROUP </th>
                                        <th>#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $sub_test=$g2->sub_test($_GET['mt']);
                                        foreach($sub_test as $st)
                                        {

                                        ?>
                                        <tr class="odd gradeX">
                                        <td><a href="?st=<?= "{$st['id']}"?>"><?= "{$st['name']}"?></a></td>
                                        <td><a href="?mt=<?= $_GET['mt'] ?>&addcart=<?= "{$st['id']}"?>">ADD TO CART</a></td>
                                        </td></tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                            
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
  <!-- /#wrapper -->    

 

	<?php } ?>				
		                 
						  
                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

  <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>



                    

</body>

</html>
