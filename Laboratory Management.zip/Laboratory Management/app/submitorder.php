<?php
error_reporting(0);
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["user"]))
{
session_unset(); 
session_destroy();
header("location:./");	
}
else
{
$user=$_SESSION["user"];
}
if(isset($_POST['submit']))
{

$data=$_POST;
unset($data['submit']);
$data['userid']=$user;
$data['labid']=$_GET['lab'];
$data['date']=date("Y-m-d");
$data['status']="waiting confirmation from lab";
$g2->insert("test_order",$data);

$data1['test_order_id']=$g2->last_test_order_by_user($user);
$test=unserialize($_COOKIE['testcart']);
foreach($test as $t)
{
    $data1['test_id']=$t;
    $g2->insert("order_tests",$data1);
}


setcookie("testcart","",time()-3600,"/");
header("location:myorders");
}



?>


<!DOCTYPE html>
<html lang="en">

<head>


  
 <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

     <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
 <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">
 <!-- Custom CSS -->
    <link href="../dist/css/g2.css" rel="stylesheet">
</head>

<body class="">
 <div id="wrapper" >

       
        <!-- Page Content -->
        <div id="page-wrapper" class="">
            <div class="container-fluid ">
                <div class="row " >
                    <div class="col-lg-14 ">
    
<center class="g2boxsh g2login" style="padding:15px;">PLACE YOUR ORDER</center>
  
    <div class="col-lg-14  " style="padding:20px;color:gray">
                    <div >
                    
                        
                        <div class="col-lg-14 ">
                       <form action="" role="form" method="post">

                        <div class="form-group ">
                               <label>PATIENT'S NAME </label>
                                            <input type="text" name="pname" class="form-control "  value="" placeholder="" REQUIRED>
                                </div>
                               <div class="form-group ">
                               <label>PATIENT'S AGE </label>
                                            <input type="number" name="page" class="form-control "  value="" placeholder="" REQUIRED>
                                </div>

                                <div class="form-group ">
                               <label>PATIENT'S GENDER</label>
                               <br>
                              <input type="radio" name="gender" value="male"> MALE  &nbsp;&nbsp;&nbsp;
                              <input type="radio" name="gender" value="female"> FEMALE
                               
                                </div>
                             <div class="form-group ">
                               <label>PATIENT'S CONTACT NO</label>
                                            <input type="number" name="p_contact" class="form-control "  value="<?php if($rno!=0){ echo $r['phone'];}?>" placeholder="" REQUIRED>
                                        </div>

                             <div class="form-group ">
                               <label>REF DOCTOR</label>
                                            <input type="text" name="dr" class="form-control "  value="" placeholder="" REQUIRED>
                                </div>

                                <div class="form-group ">
                               <label>APPOINTMENT DATE </label>
                                            <input type="date" name="apo_date" class="form-control "  value="" placeholder="" REQUIRED>
                                </div>
                                       <CENTER>
                                        <button  type="submit" class="btn  g2btnback g2boxsh" name="submit" style="border:1px solid white;color:white">Submit</button>
                                        <button  type="reset" class="btn  g2btnback g2boxsh" style="border:1px solid white;color:white">Reset </button>
                                    </CENTER>
                                        
                                        
                                        
            
                                        
                                    </form>
                                    
                                      
                                        </div></div></div>
 
    
						  
                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

  <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>



                    

</body>

</html>
