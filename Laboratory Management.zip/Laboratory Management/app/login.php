<?php
error_reporting(0);
include"../g2php/g2main.php";

if(!empty($_REQUEST['user_name']) && !empty($_REQUEST['password']))
{
	$login=$g2->logincheck($_REQUEST['user_name'],$_REQUEST['password']);
	  $login;

  $conn=$g2->db();
  



	if($login[suc]==TRUE && $login['type']=="user")
	{

		$sqlstd="SELECT * FROM `user` WHERE `email`='".$_REQUEST['user_name']."'";
                                    $resstd=$conn->query($sqlstd);
                                   $std=$resstd->fetch_array();

        $response["success"] = true;  
        $response["name"] = $std['name'];
         $response["email"] = $std['email'];
        
        $response["mob"] = $std['mob'];
        
        $response["date"] = $std['date'];

         // session_start();
        //$_SESSION['user']=$std['email'];
		
	}
    else
    {
        $response["success"] = false;  
        $response["err"] = "USERNAME OR PASSWORD IS INCORRECT";

    }
	
}else{
	$response["success"] = false;  
        $response["err"] = "ALL VALUES ARE MANDATORY";
}	
    echo json_encode($response);

?>