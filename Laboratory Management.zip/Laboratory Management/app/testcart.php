<?php
error_reporting(0);
include"../g2php/g2main.php";
session_start();
if(!isset($_SESSION["user"]))
{
session_unset(); 
session_destroy();
header("location:./");	
}
else
{
$user=$_SESSION["user"];
}

if(isset($_GET['delete']))
{
    $test=unserialize($_COOKIE['testcart']);

  unset($test[$_GET['delete']]);

  if(sizeof($test)==0)
  {
    header("location:?empty_cart");

  }
  else{
  setcookie("testcart",serialize($test),time()+(84600*30),"/");
   
   header("location:?");
   }
}
if(isset($_GET['empty_cart']))
{

setcookie("testcart","",time()-3600,"/");
 header("location:?");


}


?>


<!DOCTYPE html>
<html lang="en">

<head>

 <!-- Custom Fonts -->
    <link href="../bower_components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

     <!-- Bootstrap Core CSS -->
    <link href="../bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

 <!-- DataTables CSS -->
    <link href="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="../bower_components/datatables-responsive/css/dataTables.responsive.css" rel="stylesheet">

   <!-- Custom CSS -->
    <link href="../dist/css/g2.css" rel="stylesheet">
</head>

<body class="">
 <div id="wrapper" >

        
        <!-- Page Content -->
        <div id="page-wrapper" class="">
            <div class="container-fluid ">
                <div class="row " >
                    <div class="col-lg-14">
                      
 <center class="g2boxsh g2login" style="padding:15px;">YOUR TEST CART</center><BR>
                       
                        

 <div class="panel panel-default col-lg-14 " style="border:none;" >
                        <!-- /.panel-heading -->
                        <div class="panel-body" style="color:gray;">
                           <div class="dataTable_wrapper">
                                <?php if(!empty($_COOKIE['testcart'])) { ?>
                                 <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th> TEST MAIN GROUP </th>
                                        <th> TEST SUB GROUP </th>
                                        <th>#</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
                                
                                  $test=unserialize($_COOKIE['testcart']);
                                   foreach($test as $k=>$t)
                                    {
 
                                     ?>
                                        <tr class="odd gradeX">
                                            <td><?= $g2->main_group_name($g2->get_main_id($t))?></td>
                                        <td><?= $g2->sub_group_name($t) ?></td>
                                        <td> <a href="?delete=<?= $k ?>"><button  title="DELETE TEST"   class="btn btn-circle" style="background-color:red;color:white;"><i class="fa fa-trash"></i></button></a>
                                    <?php } ?>
                                    </tbody>
                                </table>
                                <?php } 
                                 else{
                                    echo "<center>TEST CART IS EMPTY</center>";
                                 }
                                ?>
                            </div>
                            <!-- /.table-responsive -->
                              <?php if(!empty($_COOKIE['testcart'])) { ?>
                              <hr>
                              <center>
                            
<a href="selectlab"><button  type="submit" class="btn  g2btnback g2boxsh" name="submit" style="border:1px solid white;color:white;color:white">Submit Your Test's</button></a>
   <a href="?empty_cart"><button  type="reset" class="btn  g2btnback g2boxsh" style="border:1px solid white;color:white">Clear Cart</button></a> 
                                  </center>
                                   <?php } ?>  

        
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
  <!-- /#wrapper -->    


		                 
						  
                    
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->

  <script src="../bower_components/jquery/dist/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <!-- DataTables JavaScript -->
    <script src="../bower_components/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>

    <!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
                responsive: true
        });
    });
    </script>



                    

</body>

</html>
